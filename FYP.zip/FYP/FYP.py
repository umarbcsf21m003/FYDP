from langchain_community.document_loaders import PyPDFLoader
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_chroma import Chroma
from langchain_openai import ChatOpenAI
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
import speech_recognition as sr  # Speech-to-Text
import pyttsx3
import textwrap
import os
from dotenv import load_dotenv

load_dotenv()

def work_pdf():
    # get directory from user
    directory = input("Enter the directory containing the PDFs: ")
    print("Directory:", directory)

    # Get list of PDF files
    files = os.listdir(directory)
    pdf_files = [f for f in files if f.endswith(".pdf")]

    if not pdf_files:
        print("No PDF files found in the directory.")
        return None

    print("PDF files found:", pdf_files)

    data = []

    # Pick all files
    for f in pdf_files:
        full_file_path = os.path.join(directory, f)
        print(f"Processing file: {full_file_path}")
        # Load the PDF
        loader = PyPDFLoader(full_file_path)
        #load data and add to data
        data.extend(loader.load())
        print(f"Number of pages loaded: {len(data)}")
    return directory, data


def load_credentials(_directory):
    # Set directory containing JSON credentials
    directory = _directory
    #if not directory, get directory from user
    if not directory:
        directory = input("Enter the directory containing the JSON credentials: ")
    print("Directory:", directory)

    # Get list of JSON files
    files = os.listdir(directory)
    json_files = [f for f in files if f.endswith(".json")]

    if not json_files:
        print("No JSON files found in the directory.")
        return None

    print("JSON files found:", json_files)

    # Pick the first JSON file
    base_json_name = json_files[0]
    full_file_path = os.path.join(directory, base_json_name)  # Get full path

    print(f"Selected JSON File: {full_file_path}")

    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = full_file_path
    print(f"GOOGLE_APPLICATION_CREDENTIALS set to: {full_file_path}")

    return full_file_path


directory, data = work_pdf()
load_credentials(directory)


#slit dataa
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000)
print("PDF Doc Processing...")
docs = text_splitter.split_documents(data)
print("Total number of documents: ", len(docs))


# Initialize the embeddings with the credentials
vectorstore = None
retriever = None
model = "models/text-embedding-004"
embeddings = GoogleGenerativeAIEmbeddings(model=model)
vector = embeddings.embed_query("Is this kid chatbot?")
print(vector[:5])

# Create a new Chroma instance with the desired parameters
vectorstore = Chroma.from_documents(documents=docs, embedding=embeddings)

retriever = vectorstore.as_retriever( search_type="similarity" ,search_kwargs={"k": 3})


# PRIMARY MODEL: Gemini-2.0 FLash
llm_primary = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.1)
# FREE FALLBACK MODEL (OpenAI GPT-3.5 or LLama)
llm_fallback = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.7, openai_api_key=os.getenv("openai_api_key"))

# System Prompt
system_prompt = (
        "You are a friendly and fun educational assistant designed for kids and teenagers under 18. "
        "Your goal is to help with learning by providing simple, clear, and engaging answers to questions. "
        "If the answer is not in the PROVIDED context, try your best to explain it in a fun and age-appropriate manner. "
        "And try to the question yourself for a kid."
        "You must answer FIRST PRIORITY using the provided context."
        "Use the provided context to answer questions in an easy-to-understand way."
        "Always be positive, encouraging, and use simple language that kids and teens can understand. "
        "If a question is not suitable for kids, gently guide the user toward learning-friendly topics. "
        "keep proper formatting, spacing and line breaks. The answer should be structured properly and beautifully."
        "\n\n{context}"
    )

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", system_prompt),
        ("human", "{input}"),
    ]
)

# Create Retrieval Chain
question_answer_chain = create_stuff_documents_chain(llm_primary, prompt)
rag_chain = create_retrieval_chain(retriever, question_answer_chain)

# Store chat history
chat_history = []

def get_response(user_input):
    global chat_history  # Preserve conversation across calls

    try:
        retrieved_docs = retriever.invoke(user_input)
        # Combine chat history into context
        context = "\n".join(chat_history[-5:])  # Keep last 5 exchanges
        context = "\n".join([doc.page_content for doc in retrieved_docs])
        prompt = f"Conversation so far:\n{context}\nUser: {user_input}\nBot:"
        # get context from retrieved_docs
        response = rag_chain.invoke({"input": prompt, "context": context})

        # Call the LLM with memory
        # response = rag_chain.invoke({"input": user_input})
        formatted_answer = response.get("answer", "").strip()
        # remove bold
        formatted_answer = formatted_answer.replace("**", "")
        # remove asterisks
        formatted_answer = formatted_answer.replace("*", "")
        

        # If Gemini fails, use fallback
        if not formatted_answer or any(phrase in formatted_answer.lower() for phrase in ["i don't know", "not sure", "no answer"]):
            print("\n⚠️ Gemini Model failed. Using Free AI Model...")
            try:
                # fallback_response = llm_fallback.invoke(prompt)
                fallback_response = llm_fallback.invoke({"input": user_input, "context": "\n".join([doc.page_content for doc in retrieved_docs])})
                formatted_answer = textwrap.fill(fallback_response, width=80)
            except Exception as e:
                print(f"⚠️ Fallback Model Error: {e}")
                formatted_answer = "Oops! Even the backup AI couldn't find an answer. Want to try something else?"
        
        # Save the latest conversation exchange
        chat_history.append(f"User: {user_input}")
        chat_history.append(f"Bot: {formatted_answer}")

        return textwrap.fill(formatted_answer, width=80)

    except Exception as e:
        print(f"Error: {e}")
        return "Oops! I couldn't find the answer, but learning is fun! Want to try another question? 😊"

def speak_response(text):
    engine = pyttsx3.init()    
    # Get available voices
    voices = engine.getProperty('voices')

    # Select a female voice (typically index 1)
    for voice in voices:
        if "female" in voice.name.lower():  # Try to find a female voice
            engine.setProperty('voice', voice.id)
            break
    else:
        engine.setProperty('voice', voices[1].id)  # Default to second voice (usually female)
    
    engine.say(text)
    engine.runAndWait()



def get_voice_input():
    """Captures voice input and converts it to text, tracking failures."""
    recognizer = sr.Recognizer()

    # Static variable for failed attempts
    if not hasattr(get_voice_input, "failed"):
        get_voice_input.failed = 0  # Initialize static variable

    with sr.Microphone() as source:
        print("🎤 Listening...")
        recognizer.adjust_for_ambient_noise(source)  # Reduce background noise
        try:
            audio = recognizer.listen(source, timeout=2)  # Stop listening after 5 sec of silence
            text = recognizer.recognize_google(audio)  # Convert speech to text
            print(f"\nYou (Voice): {text}")  # Display the recognized text
            return text
        except sr.UnknownValueError:
            print(f"❌ Could not understand. Try again! (Failed attempts: {get_voice_input.failed + 1})")
            get_voice_input.failed += 1  # Increment static counter
            return ""
        except sr.RequestError:
            print(f"❌ Error with speech recognition service! (Failed attempts: {get_voice_input.failed + 1})")
            get_voice_input.failed += 1
            return ""
        except sr.WaitTimeoutError:
            print(f"⏳ No input detected. Try again! (Failed attempts: {get_voice_input.failed + 1})")
            get_voice_input.failed += 1
            return ""

if not hasattr(get_voice_input, "failed"):
    get_voice_input.failed = 0  # Initialize before loop

#clear the console
os.system('cls' if os.name == 'nt' else 'clear')

# Choose input mode
mode = input("\n🔹 Choose Input Mode: [T]ext / [V]oice: ").strip().lower()

# Start chatting loop
print("\n🤖 Hello! I'm your friendly learning assistant. Ask me anything! (Type 'exit' to stop)")

while True:
    attempt = get_voice_input.failed
    if attempt > 3:
        print("❌ Too many failed attempts. Exiting...\n\t\t\tBye👋 ")
        break
    if mode == "v":  # Voice Mode
        user_input = get_voice_input()
    else:  # Default to Text Mode
        user_input = input("\n👶You: ").strip()

    if user_input.lower() in ["exit", "quit", "bye"]:
        print("👋 Bye! Keep learning and having fun!")
        speak_response("Goodbye! Keep learning and having fun!")  # Play exit audio
        break

    if user_input:
        formatted_answer = get_response(user_input)
        print("\n🤖Bot:", formatted_answer)

        # ask and play answer as audio
        # Ask if the user wants to play the audio
        ask = input("\nPlay audio? (y/n): ")
        if ask.lower() == "y":
            speak_response(formatted_answer)